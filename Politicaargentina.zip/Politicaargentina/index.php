<?php include("template/cabecera.php"); ?>

<div class="jumbotron">
    <h1 class="display-3">Bienvenid@ </h1>
    <p class="lead">En este Sitio Web encontrara la investigacion sobre Politica Argentina realizada por estudiantes de 4°15° <br> Asignatura: Base de datos <br> E.T N°26 "Confederacion Suiza" <br> Prof.: Jennifer Orellana </p>
    <hr class="my-2">
    <p>Info</p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="Jumbo action link" role="button"> Seguir leyendo. . .</a>
    </p>
</div>

<?php include("template/pie.php"); ?>
      