<?php include("template/cabecera.php"); ?>

<div class="jumbotron">
    <h1 class="display-3">Nosotros</h1>
    <p class="lead">Somos estudiantes de 4to año (Completar) </p>
    <hr class="my-2">
    <p>Mas Info </p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="Integrantes" role="button">Integrantes</a>
    </p>
</div>

<?php include("template/pie.php"); ?>